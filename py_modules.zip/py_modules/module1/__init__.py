print "init"
a=10
b=20
import file1
import file2
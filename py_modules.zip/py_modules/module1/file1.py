print "this is file1"
def fun():
	print "this is fun in file1"
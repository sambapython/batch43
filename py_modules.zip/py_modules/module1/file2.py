print "this is file2"
def fun():
	print "this is fun in file2"
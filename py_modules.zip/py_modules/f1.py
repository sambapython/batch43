print "this is f1"
def fun():
	print "this is fun in f1 modified after pyc"
fun()
print "other statements in progrm"
print "program ended"